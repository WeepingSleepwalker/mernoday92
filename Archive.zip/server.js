const express = require("express");
const app = express();
const PORT = 8000;

//MIDDLEWARE
app.use(express.json(), express.urlencoded({extended:true}))

// 1. import mongoose -require ongoose
// 2. connect to mongodb by requireing the file here
require("./server/config/mongoose.config");
// 3. create mongoose schema
// 4. use mongoose model to make CRUD functions
// 5. create routes to execute the fuctions to the db
const routesFunction = require("./server/routes/jokes.routes");
routesFunction(app);


app.listen(PORT, () => console.log(`server up on port:${PORT}`))