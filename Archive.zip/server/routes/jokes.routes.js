const JokeController = require("../controllers/joke.controllers")
console.log("---------", JokeController);


module.exports = (app) =>{

    app.get('/api/users', JokeController.findAllJokes);
    app.get('/api/users/:id', JokeController.findOneSingleJoke);
    app.put('/api/users/:id', JokeController.updateJoke);
    app.post('/api/users', JokeController.createNewJoke);
    app.delete('/api/users/:id', JokeController.deleteAnExistingJoke);
}