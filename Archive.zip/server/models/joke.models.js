const mongoose = require("mongoose");

const JokeSchema = new mongoose.Schema(
  {
    setup: {
      type: String,
      required: [true, "setup is required"],
      minlength: [6, "Setup must be at least 6 characters long"]
    },
    punchline: {
      type: String,
      required: [true, "punchline is required"],
      maxlength: [200, "punchline must be at least 6 characters long"]
    }}, {timestamps: true} );

//     age: {
//       type: Number,
//       min: [1, "You must be at least 1 or older to register"],
//       max: [150, "You must be at most 149 years old to register"]
//     },
//     email: { type: String, required: [true, "Email is required"] }
//   },



const Joke = mongoose.model("Joke", JokeSchema);

module.exports = Joke;
