//Crud
//out controller is importing the Model

const Joke = require("../models/joke.models")

 
module.exports = {

findAllJokes : (req, res) => {
    Joke.find()
        .then(allDaJoke => res.json({ message: 'success',jokes: allDaJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
},
 
findOneSingleJoke : (req, res) => {
    Joke.findOne({ _id: req.params.id })
        .then(oneSingleJoke => res.json({ joke: oneSingleJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
},

updateJoke : (req, res) => {
    Joke.findByIdAndUpdate(
        { _id: req.params.id },
        req.body,
        { new: true, runValidators: true }
    )
        .then(updatedJoke => res.json({ joke: updatedJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
},

createNewJoke : (req, res) => {
    console.log(req.body);
    Joke.create(req.body)
        .then(newlyCreatedJoke => res.json({ joke: newlyCreatedJoke }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
},
 

deleteAnExistingJoke : (req, res) => {
    Joke.findByIdAndDelete({ _id: req.params.id })
        .then(result => res.json({ result: result }))
        .catch(err => res.json({ message: 'Something went wrong', error: err }));
}
}